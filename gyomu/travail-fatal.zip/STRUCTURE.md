# 업무파탈 (Travail Fatal) 구조 설명서

© 김정환 · M.A.D.T (Moral And Digital Teacher)

## 1. 한눈에 보기
빌드 도구가 없는 **순수 HTML·CSS·JS** 앱입니다. 파일을 그대로 깃허브 페이지에 올리면 돌아갑니다.
다른 선생님은 같은 주소를 열어 "빈 수첩으로 시작"을 누르면, **각자의 브라우저에 각자의 자료**로 쓰게 됩니다(내 자료는 공유되지 않음).

## 2. 파일 구조
```
index.html            첫 페이지. 아래 파일들을 순서대로 불러옴
style.css             모든 디자인(색·글꼴·배치). 색은 맨 위 :root 변수
firebase-config.js    동기화 설정 칸(비어 있으면 동기화 꺼짐)
manifest.webmanifest  작업표시줄·홈 화면에 설치(PWA)할 때 쓰는 이름·아이콘 정보
sw.js                 앱 껍데기를 저장해 두는 파일(고치면 VERSION 숫자 올리기)
icons/                앱 아이콘 192, 512
js/core.js            공통 도구, 저장소(localStorage·IndexedDB), 대화상자(ask), 파일 읽기
js/search.js          꿈송이 검색(대충 말해도 찾기), 계획서에서 예산 후보 뽑기
js/sync.js            구글 로그인 동기화(선택)
js/app.js             모든 화면과 버튼 동작
js/pages.js           내 페이지(노션처럼 블록으로 만드는 페이지). app.js 뒤에 불러옴
```

## 3. 데이터 흐름 (교사·학생)
- 이 앱은 **교사 1인용 수첩**입니다. 학생이 접속하는 화면은 없습니다(학생용 연동이 필요하면 별도 프로그램으로 분리하는 것을 권합니다).
- 모든 자료는 `S`라는 하나의 상태(core.js)에 모이고, 바뀔 때마다 `save()`가 브라우저에 저장합니다.
  - **S** (일정·예산·수업·평가·연수·노트 글·내 페이지·업무분장·연락망·서랍) → `localStorage` (작은 글 자료)
  - **LIB** (올린 계획서·회의록·규정에서 뽑은 글자) → `IndexedDB`
  - **필기 그림, 꿈송이 사진** → `IndexedDB`
- 화면은 `S`에서 그때그때 계산합니다. 예) 오늘 게시판의 "예산 잔액"은 장부 숫자를 합해 만든 값이라, 장부만 고치면 모든 화면이 따라 바뀝니다.
- 꿈송이는 S와 LIB를 **조각**으로 쪼개 점수를 매겨 찾습니다(search.js `buildChunks` → `search`).
- 동기화를 켜면 S(잠금 노트 제외)만 구글 클라우드(파이어스토어) `users/{내 계정}` 문서 한 개에 복사됩니다. LIB·필기 그림은 올라가지 않습니다.

## 4. 자주 고칠 곳
| 하고 싶은 일 | 위치 |
|---|---|
| 색·글꼴 바꾸기 | style.css 맨 위 `:root` |
| 오늘 게시판 줄 내용·순서 | js/app.js `todayView()` (줄 하나가 `rows.push(row(...))` 한 덩어리) |
| 새 줄 추가 | `todayView()`에 줄 추가 + 설정 화면 `rowsT` 목록에 이름 추가 |
| 수행평가 단계 이름 | js/app.js 맨 위 `ASSESS_STEPS` |
| 추가·수정 창의 입력칸 | js/app.js `CFG` |
| 내 페이지 블록 종류·틀(템플릿) | js/pages.js 맨 위 `BT`, `TEMPLATES` |
| 예산 계산(총액·집행·잔액) | js/search.js `projAlloc`, `projSpent` / js/app.js `budgetView()` |
| 학사일정 읽는 규칙(날짜 모양·학년도 추정) | js/search.js `extractSchedule`, `schoolYearNow` / 확인 창은 js/app.js `scheduleDialog` |
| 연결(페이지·노트↔다른 항목) | js/pages.js `targets`, `linksHtml` |
| 꿈송이 비슷한 말 | js/search.js `SYN` (예: `'체육관':['강당']`) |
| 꿈송이가 무시할 말 | js/search.js `STOP` |
| 시험·기본값(수업 45분 등) | js/core.js `DEF` |
| 저작권 표기 | js/app.js `footer()` 와 `welcome()` |

## 5. 개인정보·오류 위험 지점 (꼭 읽기)
1. **학생 이름·성적 점수는 넣지 마세요.** 특히 클라우드 동기화와 Claude 열쇠(AI 답변)를 켠 경우에는 외부 서버로 나갑니다. 불가피하면 노트의 "이 기기에만 보관"을 체크하세요(동기화·AI 전송에서 빠집니다). 단, 올린 문서(자료실)는 "잠금" 기능이 없으니 학생 정보가 든 파일은 올리지 마세요.
2. 내 페이지도 노트처럼 "이 기기에만 보관"을 체크하면 동기화에서 빠집니다.
2. 연락망의 개인 전화번호는 동기화를 켜면 내 구글 계정 클라우드에 저장됩니다. 파이어베이스 보안 규칙(아래 7번)을 반드시 적용하세요.
3. **브라우저 기록·사이트 데이터를 지우면 이 기기의 자료가 사라집니다.** 설정 → "백업 파일 받기"를 가끔 하세요.
4. 폰 인앱 브라우저(카카오톡)는 파일 저장·설치가 제한될 수 있습니다. 크롬이나 삼성 인터넷으로 여는 것을 권합니다.
5. PDF·엑셀 읽기는 처음 쓸 때 인터넷에서 부품(pdf.js, SheetJS)을 내려받습니다. 학교망에서 막히면 텍스트(.txt, .csv)로 저장해 올리세요. 한글(hwp)·워드는 PDF로 저장해서 올려야 합니다.
6. 스캔한 PDF(그림 PDF)는 글자를 읽지 못합니다.
7. 계획서에서 예산을 뽑는 기능은 "항목 + 금액" 모양의 줄을 찾는 방식이라 **틀릴 수 있습니다.** 그래서 확인 창에서 체크한 것만 장부에 들어가게 했습니다. 넣은 뒤 숫자를 꼭 한 번 보세요.
8. 꿈송이는 올린 자료 안에서만 찾습니다. 자료에 없는 내용은 지어내지 않고 "찾지 못했다"고 합니다.

## 6. 학사일정 넣기
캘린더 화면 → "학사일정 파일 올리기"(PDF·엑셀·텍스트) 또는 "붙여넣기". 「3/2 입학식」「7.21~8.20 여름방학」「2026.05.05. 어린이날」 같은 줄을 찾아 확인 창에 보여 주고, 체크한 것만 캘린더에 들어갑니다. 연도가 없으면 3월~다음해 2월 학년도로 짐작하니 확인 창에서 날짜를 꼭 보세요. 같은 날짜·같은 이름은 다시 넣어도 중복되지 않습니다. 월별 표(달 칸 안에 날짜가 따로 있는 모양)는 줄 모양으로 바꿔 붙여야 읽힙니다. 나이스 공식 연동은 아직 없습니다.

## 7. 아직 들어 있지 않은 것
- **컴시간알리미 자동 연동**: 공식 연동 방법이 없어 시간표는 한 번 손으로 입력합니다(수업·평가 화면).
- **학교 홈페이지 공지 자동 가져오기**: 학교 홈페이지 주소와 중계 서버가 필요해 아직 없습니다.
- 한글(hwp) 직접 읽기.

## 8. 동기화 켜기 (선택, 처음 한 번만)
1. https://console.firebase.google.com 에서 프로젝트 만들기 → "웹 앱 추가(</>)" → 나오는 설정 값(apiKey 등)을 복사
2. 같은 화면에서 Authentication → 시작하기 → 로그인 방법 → Google 사용 설정
3. Authentication → 설정 → 승인된 도메인에 `내아이디.github.io` 추가
4. Firestore Database → 데이터베이스 만들기 → 규칙 탭에 아래를 붙여 넣고 게시
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{uid} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }
  }
}
```
5. `firebase-config.js`의 `null`을 `{ apiKey:"…", authDomain:"…", projectId:"…", appId:"…" }` 로 바꾸고 다시 올리기
6. 앱 → 설정 → "구글로 로그인". 폰·태블릿에서도 같은 구글 계정으로 로그인하면 이어집니다(가장 나중에 저장한 쪽이 이깁니다).

## 9. 깃허브 페이지에 올리기 (초보자용)
1. github.com 에 로그인 → 오른쪽 위 `+` → New repository → 이름 `travail-fatal`, Public → Create
2. 만들어진 저장소에서 "uploading an existing file" 클릭
3. 이 zip을 **풀어서** 안의 파일·폴더(index.html, js 폴더, icons 폴더 …)를 전부 끌어다 놓기 → Commit changes
4. Settings → Pages → Branch를 `main` / `/(root)` 로 선택 → Save
5. 1~2분 뒤 `https://내아이디.github.io/travail-fatal/` 이 열립니다. 이 주소를 다른 선생님께 나누어 주세요.
6. 크롬에서 열고 주소창 오른쪽 "설치" 아이콘(또는 메뉴 → 앱 설치)을 누르면 작업표시줄·홈 화면에 고정됩니다.

## 10. 다른 선생님이 쓰는 법 (빈 템플릿)
주소를 열면 환영 화면이 나옵니다. 이름·학교·교과·담당 반을 적고 "빈 수첩으로 시작"을 누르면 끝입니다. 자료는 각자의 기기(또는 각자의 구글 계정)에만 저장됩니다. 필요 없는 줄은 설정에서 끌 수 있습니다.

## 추가 (연수 이수번호 · 챗봇 범위 · 새 학년도)
- 연수: 이수 체크 시 이수일이 자동 기록되고, 오늘 게시판 연수 줄에서 이수번호를 바로 입력합니다 (`training.certNo`, `doneDate`).
- 꿈송이 검색 대상: 일정·학사일정·할 일, 시간표(요일별), 공문 접수·처리 수, 내 정보, 연수(이수번호 포함), 예산, 메모, 내 페이지, 연결, 업무분장, 연락망, 자료실 문서, 수업 진도, 평가, 서랍. 검색 대상이 아닌 것은 손글씨 그림뿐입니다.
- 결과 출력: 복사 / 문서로 내보내기 / 인쇄·PDF.
- 설정 > 새 학년도 시작하기 (`A.newYear`): 백업 후 시간표·일정·진도·평가·예산·연수·공문·업무분장·연락망 초기화. 메모·페이지·서랍·자료실·내 정보는 유지.

## 지난 학년도 보관함 (읽기 전용)
- 설정 > 지난 학년도 보관함에서 예전 백업(.json)을 넣으면 IndexedDB `arch`에 따로 저장됩니다. 지금 데이터(`S`)와 섞이지 않습니다.
- 보기: `#/arch/<id>` (`archView`, 항목별 토글). 꿈송이는 현재 데이터와 보관본을 함께 검색하며 출처 앞에 `[2026학년도]`가 붙습니다.
- 보관함은 기기 안에만 저장되고 Firebase 동기화 대상이 아닙니다. 기기를 바꾸면 백업 파일을 다시 넣어야 합니다.
- 개인정보: 보관본에는 잠근 메모도 들어 있으므로 백업 파일 관리에 유의하세요.

## 제목 · 도디쌤 이미지 · 워터마크
- 맨 위 제목 앞에 항상 도디쌤 이미지가 나옵니다 (올리지 않으면 기본 그림). 설정에서 이미지 교체 가능, IndexedDB `logo`에 저장됩니다.
- 제목·부제는 제목을 누르거나 ✎를 눌러 고칩니다 (`profile.title`, `profile.sub`). 브라우저 탭 이름도 따라갑니다.
- 워터마크: 화면 전체에 옅게 깔리고 인쇄에도 나옵니다. **작품 표시이므로 끄기·글자 변경 기능 없음(항상 표시, core.js wmUrl).**

## 디자인: 교무수첩 스타일
- 스프링 제본 구멍, 빨간 여백선, 줄 노트, 책갈피 리본, 색깔 인덱스 탭, 손글씨 제목(나눔펜스크립트). 모두 style.css 맨 아래 "교무수첩 스타일" 블록에서 바꿉니다.
- 오늘 화면은 왼쪽 면에 월 달력(`miniCal`)과 이번 주 기한 메모지, 오른쪽 면에 게시판 줄이 놓입니다. 폰에서는 한 줄로 쌓입니다.
- 기본 로고는 도디쌤 이미지(core.js의 `DEFLOGO`)입니다.

## 디자인 템플릿 30가지
- 설정 > 디자인 고르기. 선택값은 `profile.theme`에 저장되어 기기 동기화·백업에 따라갑니다.
- 템플릿 목록은 core.js의 `THEMES` 배열 한 줄씩입니다. 새 템플릿은 줄 하나만 추가하면 설정 화면에 자동으로 나타납니다 (책상색, 종이색, 글자색, 포인트색, 탭 방식, 글꼴). 어두운 템플릿은 줄 끝에 `, 1`을 붙입니다.

## 꿈송이 챗봇 버튼
- 오른쪽 아래에 꿈송이 그림이 떠 있고 "무엇이든 물어보세요!" 말풍선이 붙어 있습니다 (눌러도 열립니다). 기본 그림은 core.js의 `DEFMASCOT`이고, 설정에서 다른 그림으로 바꿀 수 있습니다.

## 글씨체 50가지 · 스티커 · 챗봇 디자인
- 글씨체: 설정 > 글씨체 고르기에서 본문·제목을 따로 고릅니다 (`profile.bfont`, `hfont`). 목록은 core.js의 `FONTS50` (구글 폰트 37개 + 프리텐다드·나눔·지마켓 등 CDN 13개, 모두 무료·오픈 라이선스). 고른 글꼴만 인터넷에서 불러옵니다. 오프라인이면 기본 글꼴로 보입니다.
- 스티커 (js/stickers.js): 캘린더 날짜(`S.stk`)와 내 페이지 '스티커' 블록에 붙입니다. 테이프·라벨 직접 그림 + 이모지 약 2,000개 + 내가 올린 그림(기기 안 IndexedDB `mystk`, 동기화·백업 제외). 캔바 스티커 묶음을 자동으로 가져오지는 않으며, 캔바에서 저장한 PNG를 올려 쓰는 방식입니다.
- 챗봇 화면은 규정줍줍 디자인(남색 머리, 꿈송이 얼굴, 노란 번호표, 파란 출처 띠)이며 디자인 템플릿을 바꿔도 같은 모양입니다. 스타일은 style.css 맨 아래 "꿈송이 챗봇" 블록입니다.

## 기기 연동 (컴·폰·태블릿) — js/cloud.js
- 설정 > 기기 연동 켜기에서 연동 암호(8자 이상)를 정하고, 모든 기기에 똑같이 입력하면 같은 수첩이 열립니다. 구글 로그인이 필요 없습니다.
- 내용(수첩 데이터, 자료실, 손글씨, 내 스티커, 꿈송이·도디쌤 그림, 지난 학년도 보관함)은 이 기기에서 AES-256으로 잠근 뒤 올라가며, 서버에는 읽을 수 없는 글자만 있습니다. 서버 경로도 암호에서 계산한 값이라 추측할 수 없습니다. 암호를 잊으면 복구할 수 없습니다.
- 서버: 선생님 파이어베이스 프로젝트(nation-game-cf684)의 실시간 데이터베이스 `/tf/<암호에서 나온 값>`. 다른 서버를 쓰려면 firebase-config.js에 `window.TF_CLOUD_URL = "https://…firebasedatabase.app"`를 적습니다.
- 맞추는 시점: 켰을 때, 고친 뒤 약 2.5초, 20초마다, 창을 다시 열었을 때. 규칙은 "가장 나중에 고친 기기가 이긴다"입니다. 두 기기에서 동시에 같은 곳을 고치면 나중 것만 남습니다.
- 서버 규칙이 막혀 있으면 "서버가 쓰기를 막고 있습니다"가 뜹니다. 파이어베이스 콘솔 > Realtime Database > 규칙에 아래를 추가하세요 (기존 규칙은 지우지 말고 합치세요).
  `"tf": { "$id": { ".read": true, ".write": true } }`
- 기존 sync.js(구글 로그인 + Firestore 방식)는 켜지 않으면 동작하지 않으며, 이 방식으로 대체됩니다.

## 디자인 틀 50가지 (색 30가지와 따로 고릅니다)
- 설정 > 디자인 틀 고르기. 메뉴 위치(위 탭·밑줄·알약·박스·점·왼쪽·오른쪽·하단), 종이 모양(수첩·스테노·시트·카드·창·플랫·전체화면), 게시판 줄 모양(카드·선·장부·그림자·포스트잇·알약·띠), 머리글(수첩·바·가운데·배너·미니), 책상 무늬, 모서리, 간격이 조합됩니다. 선택값은 `profile.frame`.
- 목록은 core.js의 `FRAMES`(한 줄에 `메뉴 종이 줄 머리 무늬 모서리 간격`), 모양 규칙은 style.css 맨 아래 `html[data-*]` 블록입니다. 새 틀은 `FRAMES`에 한 줄만 추가하면 설정 화면에 나타납니다.
- 기본 틀(정통 교무수첩)에는 왼쪽 펀치 구멍이 없습니다. 위쪽 스프링은 '스테노' 틀에만 있습니다.

## 한글 파일 · 일과표 · 시간표 · 컴시간알리미 (js/files.js)
- 읽을 수 있는 파일: 한글(hwp, hwpx), 워드(docx), PDF, 엑셀, csv, txt. 암호가 걸린 한글·배포용(복사 제한) 한글은 읽지 못합니다. 원본 파일은 저장하지 않고 글자만 뽑아 자료실에 저장합니다.
- 일과표: "1교시 08:50~09:35" 형태의 시각을 찾아 지금 몇 교시인지에 반영합니다 (`profile.bell`). 시간표: 교시 줄에 월~금 칸이 있는 표를 찾아 칸을 채웁니다.
- 자료실 문서는 펼치면 제목·목록·표가 구분되어 보입니다 (`readable`).
- 컴시간알리미 연동: 컴시간은 브라우저에서 직접 읽을 수 없어, GitHub Actions(.github/workflows/comcigan.yml)가 매일 새벽 comcigan-parser로 받아 `data` 가지의 comcigan.json에 저장하고, 앱이 그 파일을 읽어 설정한 내 이름(성+이름 첫 글자+*)과 맞는 수업만 시간표에 넣습니다. 학교는 gyomu/tools/comcigan-config.json 에서 바꿉니다. 다른 저장소에서 쓰려면 firebase-config.js에 `window.TF_COMCI_URL`로 주소를 적습니다. 컴시간 쪽 사정으로 막히면 파일·붙여넣기 방식을 쓰세요.

## 내 업무 (js/mine.js)
- 데이터: `S.mine = [{id, cat, title, memo, done}]` (새 학년도 때 비워짐, 백업·기기 연동에 포함).
- 올리기: 오늘 화면 '내 업무' 줄 또는 자료실 → "업무분장표 올려서 내 업무 찾기" / "표 붙여넣기" → 이름 확인 → 미리보기(체크·수정) → 저장. 전체 분장표는 `S.duties`에도 합쳐 저장(꿈송이 검색용).
- 파서 `dutyParse(text, name)`: ' | '·탭·쉼표(따옴표 처리) 표 줄에서 이름 칸이 있는 줄을 내 업무로 보고, 업무 칸을 `· ; , /` 로 쪼갭니다. 부서 칸이 비면 위 줄 부서를 이어 받습니다. 표 구조가 없는 한글 글자는 '이름 줄 바로 위 두 줄'을 부서·업무로 봅니다.
- 한글(.hwp) 표: `hwpRecords`(files.js)가 LIST_HEADER(tag 72)의 열·행 번호로 셀을 ' | ', 줄을 \n 으로 이어 붙입니다(합성 파일로만 검증, 실제 파일은 미검증).
- 화면: 접이식 줄 'r11'(기본 닫힘). 모든 칸(완료·내용·분류·메모)이 입력창이라 바로 고쳐지고, 삭제·직접 추가 가능. 설정 > 게시판 줄에서 숨길 수 있음.
- 검색: search.js 의 `S.mine` 조각 + `direct()` "내 업무" 답.
- 자주 고칠 곳: 분장표 열 모양이 다르면 `dutyParse`, 분류 기준은 부서 칸.

## 화면 크기 맞춤 (style.css 맨 끝 블록)
- 컴퓨터(1101px~) / 태블릿(601~1100px) / 폰(~600px) / 좁은 폰(~380px) / 가로 폰 네 구간. 폰에서는 머리를 줄이고 탭을 한 줄 가로 스크롤(위에 고정)로, 줄은 한 칸씩, 버튼은 44px 이상, 표는 옆으로 밀기, 알림은 왼쪽 아래로 둡니다. 깨지는 곳이 있으면 이 블록만 고치면 됩니다.

## 페이지 메모 · 공문 기록 · 캘린더 메모 · 학교 배너·급식 (js/extra.js, js/school.js)
- 페이지 메모 `S.pmemo[page]`: 모든 메뉴 맨 아래 접이식 메모칸. 캘린더 날짜별 메모 `S.dayMemo['YYYY-MM-DD']`(칸에 📝 표시).
- 공문 기록 `S.docLog=[{id,date,title,note,done}]`: 오늘 '공문' 줄 안. 기록을 더하고 빼거나 처리 체크를 바꾸면 접수·처리 개수(`S.docs`)도 같이 맞춰짐. 지난 기록은 접어서 보관.
- 보일 줄 고르기: 오늘 화면 위 [☑ 보일 줄 고르기] → 체크하면 보이고 빼면 숨김(`S.hide`). `BOARD_ROWS` 에서 목록 수정.
- 학교 배너(`schoolBanner`): 오늘 화면 맨 위. 누르면 홈페이지 열기·일주일 급식·학급 수·주소가 펼쳐짐.
- 급식·학교정보 출처: 나이스 교육정보 개방포털. 이 기기에서 먼저 직접 받고(`neisLive`, 설정한 학교 이름 기준), 안 되면 깃허브가 매일 새벽 받아 둔 `neis.json`(`gyomu/tools/neis.js`, 학교는 comcigan-config.json). 인증키 없이는 한 번에 5건만 줘서 4일씩 끊어 받음. 학생 개인별 학적·출결은 공개 연동 불가.
- 줄 열림 상태는 `tf.open` 에 저장(고치거나 체크해도 다시 안 닫힘).


## 서랍 (js/drawer.js)
- 하단 서랍: 즐겨찾기 ★ 줄 + 펼치면 검색·분류 탭(전체/즐겨찾기/최근/내 분류)·넣기·✎고치기·✕빼기·백업 저장/불러오기.
- 데이터: `S.links[] = {id,name,url,cat,fav,last}`. 주소만 저장(비밀번호 없음), javascript: 주소는 거부.
- 자주 고칠 곳: `drawerHtml()`(화면), `A.add_links/dwEdit/dwDel/dwFav`(동작), style.css 끝 `.dw*`.
- 위험: 브라우저 데이터를 지우면 목록이 사라짐 → 백업 저장 권장. 백업 파일에는 내 사이트 주소가 담김.


## 메신저 붙여넣기 (js/inbox.js)
- 오늘 화면 [📨 메신저 붙여넣기] → 경기도 메신저 글을 붙이면 날짜 줄을 찾아 일정/할 일/내 업무로 나눠 미리 보여 주고, 체크한 것만 추가.
- 분류 규칙: '까지·마감·제출·회신·신청·입력'은 할 일, '연수·회의·행사·기간·실시'는 일정, 날짜 없는 제목은 내 업무(기본 해제). `IBX`·`ibxParse()`에서 고침.
- 날짜는 2026. 11. 25. / 11월 25일 / 11/25 형식을 읽고, '~' 범위는 제목에 (~12/4)로 표시.


## 꾸미기 찾기
- 모든 쪽 메뉴줄 오른쪽 빨간 [📨 메신저 붙여넣기] 버튼, 설정 맨 위 [꾸미기 바로가기](글씨체, 디자인·색).
- 제목 굵기는 style.css 맨 끝 `font-weight:900` + `-webkit-text-stroke` 블록에서 조절.


## 설정 접기·설치 안내
- 설정의 각 구역(h3)은 extra.js `setFold()`가 자동으로 접는 칸(details.sec)으로 감쌉니다. 열고 닫은 상태는 기억.
- 설치·작업표시줄 고정·위젯처럼 쓰기 안내는 app.js `setView()`의 `.guide` 구역에서 고침.


## 메모 디자인 100가지 (js/memo.js)
- 모양 10종(포스트잇·줄노트·모눈·점노트·접힌 색종이·테이프·구름·편지지·이중 테두리·형광펜) × 파스텔 10색. 고른 번호는 `S.profile.memo`(0~99).
- 적용 대상: 페이지 메모, 캘린더 날짜 메모, 기록 본문. 대상을 늘리려면 `MSEL` 선택자에 추가.
- 기본값 `MEMO_DEF`(포스트잇·레몬), 기본 테마는 core.js `themeApply`의 'mint', 기본 글씨체는 내 기기 글씨체(`SYS`).


## 플래너 스킨·화면 순서·자료 원본 (이번 추가)
- 플래너 스킨: style.css 맨 끝 `html[data-skin="planner"]` 블록(기본). 설정 맨 위 [화면 스타일]로 기존 수첩과 전환(`S.profile.skin`).
- 화면 순서: js/order.js. 줄 순서·메뉴 순서는 `S.order`에 저장, 오늘 화면 [↕ 순서 바꾸기]·설정 맨 위. 프리셋(업무·예산·일정·수업 중심) 포함.
- 자료 원본: js/docs.js. 올린 파일 원본은 IndexedDB(`file:<자료id>`)에 보관 → [원본 열기](PDF는 새 탭, 한글·엑셀은 내려받기 후 열림)·[표로 바로 보기](엑셀)·[크게 보기]. 백업 파일에는 원본이 들어가지 않으니 다른 기기에서는 다시 올려야 함.
- 꿈송이 AI 정리 모델은 search.js `askClaude`의 `claude-haiku-5-5` (사용자가 설정에 넣은 본인 API 키로 호출, 질문 1회 약 1원).

## 꿈송이 비서 모드 (js/agent.js) — "나만의 자비스"
- 켜는 법: 꿈송이 채팅창 위의 🔑 칸에 Claude 키(sk-ant-…) 붙여넣기 → 저장 (localStorage `tf.claudeKey`, 설정의 열쇠 칸과 같은 값).
- 동작: 키가 있고 ① "추가·넣어·집행·수정…" 같은 시키는 말이 있거나 ② 50자 이상 긴 글(메신저)을 넣으면 Haiku 5.5가 도구(tool_use)로 계획을 만들고 **카드로 먼저 보여 준 뒤 [적용]을 눌러야 반영**됩니다. 삭제는 없습니다.
- 도구: add_event(일정/할 일) · complete_item · add_mine · add_note · add_spend · add_budget_line · edit_budget_line · add_budget_project.
- 실패 시(키 오류·잔액 부족·네트워크) 안내 후 기존 찾기 검색으로 자동 전환.
- 자주 고칠 곳: AG_TOOLS(도구 목록), agPlan(검증·설명 문장), agDo(실제 반영), agContext(AI에 넘기는 현황), system 프롬프트(agentTry).
- 개인정보: 요청 문장 + 예산/일정 현황이 Anthropic으로 전송됩니다(잠금 노트 제외). 학생 이름 입력 금지.

## 소개 페이지 · 체험판
- `intro.html`: 업무파탈 소개(이름의 뜻, 기존 교무수첩·노션의 불편, 시그니처 기능, 설치 방법, 한계). 단독 정적 페이지.
- 기본 화면(플래너 스킨)은 소개 페이지와 같은 디자인: 크림색 줄노트 배경, 2px 진한 선+딱지 그림자, 파스텔 카드, 굵은(900) 제목. 수정은 style.css 맨 아래 "소개 페이지 디자인을 기본 화면으로" 블록.
- `demo.html`: build.py가 만드는 단일 파일에 `window.TF_DEMO=1`을 넣은 체험판. 저장소 키가 `travailfatal.demo` / IndexedDB `travailfatal-demo`라 **내 수첩 데이터와 완전히 분리**, 예시 데이터로 자동 시작, 기기 연동·서비스워커 꺼짐, 상단에 빨간 체험판 띠(#demostrip).
- 수정 후 `python3 build.py` → `cp dist/demo.html demo.html`.

## 연수: 이수 시간 합계 · 연수 사이트
- 연수 줄(r7) 맨 위에 "이수한 연수 합계 N시간(필수·개발 구분, 개발 목표 진행률)" 막대. 계산은 app.js 연수 블록(`totH`, `reqH`, `dev`).
- 연수 사이트: 사용자가 직접 추가·수정·삭제(기본 목록 없음). 저장 위치 `S.trSites[{id,name,url}]`, 코드는 js/drawer.js 맨 아래(`trSitesHtml`, `A.trSiteAdd/Edit/Del`). 주소는 http(s)만 허용(javascript: 등 차단).

## 11. 디데이·기한 알림·위젯 (추가분)
**파일**: `js/dday.js`(디데이·알림 막대), `js/setui.js`(설치·위젯 버튼), `widget.html` + `js/widget.js`(위젯)

**디데이** — 오늘 화면 위쪽 작은 칩(가까운 4개)과 게시판 줄 `r13`(추가·삭제·알림 설정). 자료는 `S.dday = [{id,title,date}]`. 캘린더에도 자동으로 나옵니다(`allEvents()`에 한 줄 추가).
**기한 알림** — 할 일·수행평가·예산 집행 기한·연수 기한·디데이가 **N일(기본 2일) 안**이면 화면 아래 얇은 막대로 알립니다. 한 줄로 접혀 있고 누르면 펼쳐집니다. `×`는 "오늘은 그만 보기"(새 기한이 생기면 다시 나옴). 설정값은 `S.profile.alarmDays`(0~14, -1=끔). 서버가 없으므로 **앱·위젯을 열어 둔 동안만** 알립니다. 브라우저 알림을 허용하면 열 때 하루 한 번 알림창도 띄웁니다(Notification API).
**작업표시줄 설치·위젯 버튼** — 설정의 "작업표시줄에 고정" 안내 칸(app.js `.guide`) 위에 `setui.js`가 [앱으로 설치하기]·[위젯 열기] 버튼을 붙입니다. 설치는 PWA(manifest.webmanifest) 방식이고, 작업표시줄 아이콘 오른쪽 클릭 메뉴에 "위젯 열기"(manifest `shortcuts`)가 나옵니다.
**위젯** — `widget.html`은 본 앱과 같은 `localStorage`(`travailfatal.v1`)를 **읽기만** 합니다(본 앱 자료를 덮어쓰지 않으려고). `allEvents()`와 비슷한 계산이 `js/widget.js`에 복사되어 있으니 **기한 종류를 추가하면 두 곳을 같이 고치세요.**
**자주 고칠 곳**: 알림 대상 종류 `dday.js ALARM_KINDS` / 알림 기본 일수 `alarmDays()` / 알림 막대 모양 `style.css` 끝의 `#alarmbar` / 위젯 모양 `widget.html` 안 `<style>`.
**위험 지점**: ① 위젯·알림은 같은 브라우저·같은 주소에서만 자료를 봅니다(다른 브라우저·기기는 비어 보임). ② 닫혀 있는 동안은 알림이 가지 않습니다. ③ `sw.js`의 `FILES`에 새 파일을 넣고 `VERSION`을 올려야 설치한 앱에 반영됩니다.

## 캘린더 강화·챗봇 이동·연락망 표 (js/cal2.js)
- 캘린더: 종류별 색(CAL_KINDS, CSS `.k-종류`), 범례, 달별 "업무·일정 한눈에" 목록(calAgenda), 날짜에 마우스를 올리면 작은 일정 창(.calpop, 떼면 사라짐). 새 종류를 만들면 CAL_KINDS와 style.css 색을 같이 추가.
- 메신저 붙여넣기 후: 날짜가 있는 항목은 모두 캘린더 항목(S.items)으로 들어가고, 첫 날짜의 달로 캘린더가 열립니다. 날짜가 있는 "내 업무"는 [업무] 할 일로도 캘린더에 들어갑니다.
- 챗봇 창: 머리줄을 끌어 옮김(위치 localStorage `tf.chatpos`), 이름은 설정 "챗봇 이름"(S.profile.botName). 채팅창은 history에 쌓이지 않아 뒤로가기는 바로 이전 화면으로 갑니다.
- 연락망: contactTable() — 부서별 묶음 표, 전화·내선 눌러 걸기(tel:).

## 수업·평가·아카이브 (class2.js / arch.js / files2.js)
- arch.js: `ingestFiles(files,{from,kind})` — 모든 파일 올리기의 단일 통로(읽기→LIB 저장+원본 보관→`reflectDialog`로 일정·예산·학사·시간표·운영표 반영 여부 질문). 전역 Ctrl+V 붙여넣기/끌어놓기, 자료 아카이브 화면(`filesView`), 페이지별 `fileBox(page,kind)`.
- class2.js: `classView`(시간표 설명 + 교수학습 운영표/진도: `S.plans`,`S.prog[반]={planId,upto}`, `parsePlan`/`planFromText`, `syncProg`→`S.lessons`의 `pg-` 항목) · `evalView`(`S.exams`,`S.assess`,`S.rubrics`) · 캘린더 연동(`allEvents` 래핑).
- files2.js: 오프라인 HWP(CFB) 파서. 자주 고칠 곳: `RUB_PRESETS`, `parsePlan` 정규식.
- 주의: 업로드한 파일 원본은 IDB `file:<id>`에 보관(개인정보 포함 가능). 단일 빌드는 한 스크립트라 최상위 const 이름이 겹치면 안 됩니다.

## 기록 회의별 · 시계 · 꾸미기 · 격려 (notes2.js / deco.js)
- notes2.js: `S.meetings`(회의 이름 목록, 사용자가 추가), 노트의 `meeting` 필드. 기록 목록 날짜순/회의별 전환(`UI.nv`), 「제목 보고 회의 자동 분류」(`S.profile.autoMeet`, 선택).
- deco.js: 시계(`S.profile.clock`, 급식 `lunchS/lunchE` — 비면 일과표의 가장 긴 쉬는 시간), 꾸미기(`S.profile.deco` {on,dim,blur,washi,stick}, 배경 사진은 IDB 키 'deco'에 1600px JPEG로 저장), 격려 500개(`CH_A` 50 × `CH_B` 10, `S.profile.cheer`='today'|'off'). 설정 화면에 `.decoset` 카드가 자동 삽입됩니다.
- 주의: 단체사진은 학생 얼굴이 담긴 개인정보이므로 이 기기(IDB)에만 저장되고 클라우드 동기화에 포함되지 않습니다.

## 일과표 파일 · 행사 일과 (bell2.js)
- 설정의 시계 카드: [일과표 파일 올리기](한글·엑셀·PDF → `extractBell`로 읽어 기본 일과표를 그대로 교체), [행사로 일과가 바뀌었어요(붙여넣기)] → `bellFlow(text)`.
- 행사 일과는 `S.profile.bellOv=[{from,to,label,bell,lunch,drop}]`. 오늘이 기간 안이면 `clkPeriods/clkLunch/periodInfo`가 이것을 쓰고, 기간이 지나면 `bellPrune`이 지워 원래 일과표로 자동 복귀합니다. `drop`=적지 않은 교시는 없는 것으로.
- 파일·붙여넣기 어디서든(arch.js 반영 창/붙여넣기 창) "⏰ 일과표·행사 일과로" 버튼이 나옵니다. 고칠 곳: `bellFind`(시각 인식 정규식), `bellDates`, `bellLabel`.

## 포스트잇 (postit.js)
- `S.postits=[{id,text,date,color,done,min,x,y}]`, 전체 내리기는 `S.profile.pstDown`. 화면 오른쪽 가장자리에 쌓이고(`#pstLayer`), 머리를 끌면 자유 이동(x,y 저장). [–]=한 줄로 접기, [✓]=내리기(완료), 하단 [📌 N ▼ 내리기]=전부 숨김/올림.
- 만들고 관리하는 곳: 오늘 화면의 「오늘 메모」 안(`pageMemo('today')` 래핑). 직접 적기 또는 앞으로의 일정에서 골라 만들기. 기한이 지나면 붉은 머리로 표시.

## 선생님 시간표·공강·수업 교환 (teach.js)
- 컴시간 전체 자료(`COMCI_URL`의 data 가지 comcigan.json, localStorage `tf.comci.all`에 6시간 캐시) → `PEOPLE`. 컴시간은 이름이 두 글자뿐이라 같은 이름은 「과목별 4시간 이상 + 같은 칸 겹침」이면 다른 사람으로 나눕니다(자율·동아리 칸은 양쪽에 같이 표시).
- 수업 화면 ③: 선생님 이름 검색→시간표, 나와 공강이 같은 선생님 순위, 수업 교환(같은 반의 다른 교과 시간과 맞바꾸기)·대강 가능 교사, 바뀐 시간표 미리보기·요청 문구 복사. 학년별 색은 `S.profile.gcol`(수업 화면에서 변경), 오늘 화면에 주간(세로) 시간표 `wkGrid`.
- 체험판(`TF_DEMO`)은 `cmcDemo()`가 만든 가상 학교·선생님으로 같은 기능을 체험합니다(실제 학교 자료 요청 없음). 개인정보: 다른 선생님 시간표는 학교 공개 시간표 자료입니다.

## 날짜 화면 · 손글씨 사진 (daypg.js, scan.js)
- daypg.js: 캘린더 날짜 클릭(`A.calDay` 래핑) → `<dialog id="daypg">`. 일정/할 일/업무 입력(→`S.items`, 업무는 제목 앞 `[업무] `), 날짜 메모(`S.dayMemo`), 스티커(`S.stk`, 이 화면에서만 붙이기), 사진(`S.dayImg[date]`=목록, 원본은 IDB `dimg:<id>`, 기기 전용). 달력 칸에는 스티커 2개·🖼 표시만. 아래 기존 칸은 그대로.
- scan.js: 📷 손글씨 사진 → Claude Haiku 비전(본인 키 `tf.claudeKey`) → 확인 창(종류·날짜·시각·제목 수정, 체크) → `S.items` 추가. 체험판은 예시 결과. 사진은 1600px로 줄여 전송(학생 정보 주의).
- app.js 오늘 카드: 시간표는 한 줄(가로 스크롤), 월~금 탭+날짜(`UI.tdDay`, `A.tdDay`). 말풍선 `#chatbub`은 꿈송이 머리 위(style.css 끝).
- 수정 위치: 프롬프트=scan.js `scanRun`, 사진 크기=`scImg`.

## 내 목록 · 캘린더↔시간표 연동 (cust.js)
- 드롭다운 끝의 「＋ 직접 추가…」/「✎ 내 목록 관리…」: 종류 선택(날짜 화면·아래 일정칸·손글씨 확인창)과 자료 종류(`#upk`,`#arcKind`)에 적용. 저장 `S.profile.lists` ({kind:[{n,b:'event'|'todo'}], upk:[], arc:[]}). 새 드롭다운에 쓰려면 `data-cus="kind"`(+`data-work="1"`) 또는 `CUS_STR`에 선택자 추가. 예산·학급 등 ID 값 드롭다운은 일부러 제외.
- 사용자 종류는 item.tag(이름표)+item.cat(성격)로 저장, `cusMk(값,제목,교시)`가 항목 필드를 만듭니다.
- 교시 연동: item.per 또는 제목의 「7교시」「3~4교시」(「4교시 후」는 제외)를 `cusPers`가 읽고, 오늘 카드 하루 시간표·주간표(`gridTable` o.dates)의 해당 날짜·교시 칸에 📌 표시(`cusSlot`). 메신저 붙여넣기(inbox.js)는 제목이 그대로 들어가므로 자동 연동.
- 날짜 화면: ✕ 닫기 버튼, 바깥(어두운 배경) 클릭·Esc로 닫힘. 폰은 아래에서 올라오는 전체폭, 태블릿·PC는 중앙 창.

## 시간표 변경 감시 (tt2.js)
- 앱 열기·화면 복귀·오늘 화면 렌더 시(최소 5분 간격) `ttwWatch`→`comciSync(true)`로 컴시간 자료를 다시 받고, 달라지면 `ttwApply`가 자동 적용 + 상단 🔔 배너(오늘/내일 표시, [확인]/[되돌리기], 브라우저 알림 허용 시 알림). 이전 시간표는 `S.profile.ttChg.prev`.
- 한계: 컴시간 자료(data 브랜치 comcigan.json)가 GitHub Actions(평일 새벽 5시)로 갱신된 시점까지만 반영됩니다. 체험판은 7초 뒤 예시 변경 알림을 한 번 보여 줍니다.

## 마스킹테이프·포스트잇 보강
- 설정 「🎀 마스킹테이프 제목」: `S.profile.deco.washi` = 'pink|yellow|sky|mint|purple|kraft|orange|navy'(빈 값=사용 안 함). deco.js `WASHI` 목록 + style.css `body[data-wt=…]`. 새 종류는 두 곳에 한 줄씩 추가.
- 오늘 메모 제목 옆 「📌 포스트잇 기능 있어요」 배지(postit.js `pageMemo`). 날짜 화면: 입력 시 「포스트잇으로도 붙이기」 체크(선택), 목록 항목마다 📌 버튼(`A.dpPst`).

## 부팅 시 자동 열기 (boot.js)
- 설정 「💻 컴퓨터 켜면 자동으로 열기」: 브라우저(엣지/크롬)·대기 시간·평일만 선택 → `travail-fatal-start.bat` 생성(`bootMake`). 사용자가 `shell:startup` 폴더에 넣으면 부팅 때 `--app=주소`로 열림. 웹 페이지가 스스로 부팅 실행은 불가하므로 시작 파일 방식. 윈도우 전용, 체험판에서는 생성 안 함. 저장: S.profile.bootBr/bootWk/bootDl.

## 오늘의 한마디 (quotes.js / deco.js)
- quotes.js: `QT_Q`(명언 500 [문장,출처]) · `QT_G`(격언·속담·사자성어 500) · `QT_C`(위로의 글 500, 직접 작성·출처 없음). 원본 텍스트는 data/q_a.txt · g_a.txt · c_c.txt(`문장|출처`), 고칠 때는 txt를 고치고 JSON으로 다시 변환.
- deco.js `cheerPick(shift)`: 날짜 시드로 매일 다른 글(간격 7 ↔ 500 서로소라 500일 겹치지 않음). `S.profile.cheerKind`(mix/q/g/c), `cheer`(오늘 화면 맨 위), `cheerClk`(시계). 「다른 말」 버튼은 shift만 올림.
- 주의: 출처는 전해 오는 기록과 기억에 기초한 것이라 번역·귀속 오류가 있을 수 있음. 틀린 줄은 txt에서 삭제.

## 펜 메모 · 끌어서 순서 · 유튜브 (pen.js)
- 펜 메모: 캔버스 PNG를 IDB 'penm'에 저장(동기화 제외, `pnList`). 위치 구분 `sc`('p:페이지' / 'd:날짜'). 펜 감지 시 터치(손바닥) 무시.
- 끌기: `drBegin`(pointer 이벤트, 마우스 6px·터치 길게 350ms·손잡이 ⠿ 즉시) → `drMerge`가 `S.order.nav/rows`에 저장. 메뉴는 `nav.nav a`, 줄은 `row()` 래퍼가 붙인 `.drg`, 순서창은 `A.ordPick` 래퍼가 손잡이를 붙임.
- 유튜브: `#ytfab`·`#ytpan`(body 직속이라 화면이 다시 그려져도 재생 유지), 설정 `S.profile.ytBtn`, 즐겨찾기는 localStorage 'tf.yt'. 뮤직 사이트 자체는 임베드 불가 → 새 창.
## 오늘 도우미 (helper.js)
- `S.lessonLog[]`(수업 후 기록) · `S.cellLink{}`('요일-교시'→URL, 시간표 칸 🔗) · `S.endCk/endCustom`(학기말 점검표) · `S.workout{}` · `S.weekRv{}`(한 주 소감). 학생 메모는 IDB 'stum'(개인정보라 동기화·백업 제외). 설정 `helperOn`.
- 화면이 render()로 직접 다시 그려져도 카드가 사라지지 않도록 portal.js 맨 끝 MutationObserver가 재부착.
## 교무포털 담기 (portal.js)
- 북마클릿(`ptCode`)이 포털 화면의 글·첨부 링크(+같은 사이트 링크 최대 30쪽, 읽기 전용·로그아웃/삭제/저장성 링크 제외)를 읽어 `window.open`+`postMessage`로 업무파탈에 전달 → `ptReceive`가 자료 보관함 LIB(kind '교무포털', from 'portal')에 저장하거나 ibxParse로 일정 뽑기. `e.source===window.opener`일 때만 받음. 포털 주소 `S.profile.portalUrl`(사용자 입력).
- 위험: 학생 개인정보가 보이는 쪽은 체크 해제 안내. 포털이 javascript: 북마클릿·팝업을 막으면 「복사해서 붙여넣어 담기」 사용.
## 퇴근 타이머 (deco.js)
- `S.profile.offOn/offT/offMin` → `clkOffTxt()`(1초 갱신, 평일만, 퇴근 후 5분간 🎉 문구).

## 나만의 점검표 · 수업 자료 연결 · 모든 창 바깥 클릭 닫기 (js/helper.js)
- 나만의 점검표: S.chkLists[{id,name,items[{id,t,done}],daily,day}] — hpChkOpen(). 「매일 새로 시작」은 hpChkDaily()가 날짜 바뀌면 체크 해제. 추천 틀은 HP_CHK_TPL.
- 학기말 점검표: S.endList(편집본)/S.endCk(체크)/S.endCustom — hpTerm()에서 이름·항목 고치기/삭제/추가/초기화.
- 수업 자료 연결: S.cellLinks{'요일-교시':[{id,n,u,k}]} — 딜시·한 번뿐인 인생·HTML 슬라이드 파일(IDB 'cl:'+id, 이 기기에만)·임의 URL 여러 개.
- 수업 기록: S.lessonLog (이 브라우저 localStorage, 백업 JSON에 포함, 클라우드 동기화 켰을 때만 동기화). 「수업 및 시간표」 맨 아래에 표시.
- 포털 담은 자료: 자료 아카이브(LIB, IDB 'lib') → 교무포털 폴더. 📁 이동(A.arcMove), 💾 저장(A.arcSave), 모두 폴더에 저장(ptSaveAll).
- 모든 <dialog>: 어두운 바깥 영역 클릭 시 닫힘(helper.js 끝, data-noclose로 제외).
- 개인정보 위험: 학생 메모('stum')·HTML 슬라이드('cl:')는 기기 전용(동기화·백업 제외).

## 학급 관리 (js/classmgmt.js) — 담임·교과 선택형, 학생 정보는 이 기기 전용
- 저장: 학생 데이터 CM → IndexedDB 'cmdata'(이 기기). S(localStorage)·클라우드 동기화·일반 백업(JSON)에 들어가지 않음. 설정(메뉴 이름·켠 기능·구분 항목·안내문 틀·연동 링크)만 S.cm.
- CM = {classes[{id,name,stu[{id,no,name,bd,tel,memo}]}], att, logs{모듈id:[]}, grid{모듈id:{반id:[항목]}}, duty[], ev[], mood, pick, list, pin(해시), fired}.
- 기능 목록 CM_MODS(담임/교과/공통) + 사용자 정의(S.cm.custom). 켜기·끄기: S.cm.mods. 이름·구분·상태 이름은 ⚙️로 편집(S.cm.names/tags/lab).
- 엔진: att(출결) · log(상담·특이사항 등) · grid(수합·수행평가) · duty(1인1역·청소, 요일·날짜·순환·알림 20초 타이머) · ev(행사, 파일 끌어놓기→cmEvParse) · mood · pick · list · bday · tel · tpl · prof(학생 한 장 요약).
- 명렬: 엑셀(번호·이름·생일·보호자 연락처·메모), 시트 = 반. 양식 내려받기 A.cmTpl, 올리기 cmImportFile(lib/xlsx).
- 챗봇: buildChunks 래핑 → type 'class', priv:true(외부 AI 전송 제외, 기기 안 검색만). PIN 잠금 중엔 제외.
- 보안: PIN(SHA-256 해시, CM.pin), 암호 백업 .tfcm(AES-GCM, PBKDF2), 모두 지우기.
- 개인정보 위험: 폰·PC 분실, 브라우저 데이터 삭제 시 복구 불가 → 암호 백업 안내. 기기 간 자동 이동 없음.

## 연간 교육·훈련표 (js/yearplan.js) — 해마다 반복되는 연수·교육·훈련·행사
- 저장: S.yp = {year, rows[{id,name,rule,cells{'1t'..'2x':{d,t,n,ok}}}], hist{학년도:rows}} (localStorage·백업 포함). 칸 키: 학기(1·2)+대상(t교직원·s학생·p학부모·x기타/훈련). 참석은 인원 숫자(n)만, 이름 명단 없음.
- 새 학년도: A.ypRoll — 줄(틀) 유지, 칸 비움, 지난해는 hist 보관. 학년도 불일치 시 노란 안내 표시.
- 연동: allEvents()에 ypEvents()(캘린더·디데이 알림), 오늘 화면 📚 임박 카드(14일 안·날짜 지남, ypInject+MutationObserver), 꿈송이 buildChunks 래핑(type 'training').
- 가져오기: 붙여넣기·CSV·엑셀(ypImportRows) — 노션 표(이름·필요연수·6칸) 또는 내려받은 양식(이름·기준·8칸) 자동 구분. 날짜 3.10/3/10/2026-03-10 인식(3월 기준 학년도).
- 예시 줄 YP_PRE는 참고용(기준은 해마다 공문에 맞춰 수정). 증빙 파일: 페이지 하단 파일 올리기(PAGE_KIND.yp).
## 공문 사진 (js/scan.js 끝) · 떠 있는 학급 관리 버튼 (js/classmgmt.js 끝)
- 오늘 「공문」 줄 아래 📸/🖼 → Claude 비전(본인 키)으로 제목·발신·기한·할 일 추출 → 확인창 → S.docLog 등록, 선택 시 캘린더·아카이브 보관. 키 없으면 직접 적기. 학생·학부모 실명·연락처는 옮기지 않도록 지시.
- #cmfab: 메뉴 설정·화면 틀과 무관하게 항상 표시되는 🏫 버튼(href #/cm).

## 꿈송이 2 — 규정줍줍 + 비서 모드 (js/bot2.js, v69)
- 입구: `ask1` 교체. 키(`tf.claudeKey`) 있으면 `b2Loop`(도구 호출 반복, 최대 9회, 모델 `tf.botModel` 기본 claude-haiku-5-5), 없으면 규정줍줍(`b2RuleBlocks`)+기존 찾기.
- 읽기 도구(바로 실행): search_site, find_rule, list_library, read_library, get_calendar, get_day, list_work_cards, get_budget, list_training, list_notes. 새 읽기 도구는 `B2_READ`에 정의 + `b2Run`에 case 추가.
- 쓰기 도구(제안 카드→[적용]): 기존 AG_TOOLS + add_wk_card, update_wk_card, set_training_date, add_day_memo. `agPlan`/`agDo`를 감싸서 확장. 적용은 commit()이라 되돌리기 가능. 삭제 도구는 없음.
- 규정줍줍: 자료실(LIB) 문서를 450자 단위로 쪼개 낱말 겹침으로 점수(규정 종류 ×1.5). 결과는 파일 이름과 함께 표시.
- 개인정보: 학생·교직원 실명 명단은 도구로 노출되지 않음(수첩에 없음). 키 사용 시 찾은 내용이 Anthropic API로 전송됨(잠금 노트 `lock`은 search_site·list_notes에서 제외).

## v76 보강 (js/work2.js, js/more.js)
- work2.js — 내 업무 카드 확장: stage/cd/sd/log/links/tplId 필드, S.wk.tpl(해마다 되풀이), 탭 yr·mo·bd·st(workView 래핑), 인수인계서(.doc), 기한 임박 카드(오늘 .wktoday).
- more.js — 예산 점검 패널(budgetView 래핑: 기한 경고·월별 집행·에듀파인 잔액 p.edu·품의번호 l.no·결재 l.st·사업 복제), 연수(t.apply 신청마감→allEvents, t.note 소감, 법정 의무연수 넣기, 이수 내역 .doc), 기록(회의록 양식, 후속 조치 모아보기 n.fdone), ypSig 신호등, 오늘 카드 .mttoday(S.focus 꼭 할 일 3개, 퇴근 전 점검, 주간 돌아보기 S.weekly).
- 연락망 c.memo(최근 연락), 연수 목표 시간 S.profile.reqTarget/devTarget/totTarget.

## v77 (js/work3.js)
- 업무일지 `#/wlog`: S.wlog[{id,d,t,cat,m,card}], S.wlogDay{날짜:{done,block,next,feel}}(감상·성찰). 카드 연결 시 카드 일지(c.log, wl=id)에도 기록. 월간 .doc 내보내기, 작년 오늘, 챗봇 도구 get_worklog/add_worklog.
- 카드: c.type(행사·연수·조사·예산)→WK_TYPES 단계·필요 문서, c.docs[{id,name,kind}](파일은 LIB=자료 아카이브, from:'work'), c.evt(캘린더 일정 id), c.team, ✕ 즉시 삭제(undoBar 8초).
- 올린 파일 전부 아카이브: readFile 래핑(ingestFiles 밖에서 읽은 파일도 LIB에 저장). 화면별 자료 상자는 접힘(.pgfdet). PDF 원본 열기는 앱 안 창(pdf.js).
- 캘린더: UI.calHide(종류 거르기), S.repDone{반복일정id:{날짜:true}}, 일정 3건 이상 몰림 ⚠, 그 날 기한 업무 카드.

## v78~v80 추가 (공문 단계 · 예산 비고 · 예산 집행 서류)
- **공문 단계(v78, js/more.js)**: DL_ST ['기안','접수','결재','처리중','완료'], 공문 항목의 `st` 필드. docLogBody 래퍼에 단계 select(`[data-dlst]`)와 「진행 중 모아보기」.
- **예산 비고(v79, js/more.js·app.js)**: 사업 `p.note`, 항목 `l.note`, 지출 `s.note`. 챗봇 검색 chunk에도 포함.
- **예산 집행 서류·업체(v80, js/budget2.js)**: 지출(spend)에 `type`(유형) `stg`(단계, 비면 '지출') `vendor`(업체) `docs`(체크한 서류[]) 추가. 설정은 `S.bdTypes`(유형별 필요 서류, 직접 수정 가능), `S.bdCfg {est 견적 기준액, end 예산 마감일}`, `S.vendors {업체:{tel}}`.
  - bdPanel2(): 단계 칩·서류 체크·업체·집행 속도·불용 경보. budgetView 래퍼로 첫 사업 앞에 끼움. 접힘 상태는 `UI.bdOpen`.
  - A.spendAdd 덮어씀: 잔액 표시·초과 시 확인·유형/업체 입력. A.bdBack(행사일 역산 일정 4개 → S.items, tag '예산'), A.bdTplEdit, A.bdCfgEdit, A.bdReport(결산 .doc).
  - mtWarn·buildChunks 래퍼: 오늘 카드에 불용·서류 미비, 챗봇에 업체·집행 정보.
  - 고칠 곳: 기본 서류 목록 = BD_TYPES0, 기본 견적 기준 = bdCfg() 안의 2000000, 기본 마감일 = 12월 20일.
  - 개인정보 주의: 업체 연락처는 이 기기 localStorage에만 저장됩니다.

## v81 (예산 요구서·계획서, 업무 뼈대)
- **js/budget3.js**: `S.bdReq` 요구서(사업·학년도·항목표[단가×수량·산출 근거·올해 집행 참고]·계획서 4칸·작년 참고 글). A.rqNew(올해 사업 복사 가능)/rqItem/rqPlan/rqRef(자료 아카이브 LIB에서 사업명 근처 글 발췌)/rqAI(키가 있을 때 Claude 초안, 모델은 tf.botModel)/rqDoc(요구서·계획서 .doc).
- **js/skel.js**: 업무 뼈대. SK_BUILT(범용 7종, 코드에 있음) + `S.skel`(내 전용, 사용자 데이터). A.skUse → 내 업무 카드(wkN) + 단계 날짜 + 캘린더(tag '업무'). 내보내기/가져오기는 .json(`{tf:'skel',skel:[...]}`).
- **배포 원칙**: 코드에는 특정 교사·학교의 업무를 넣지 않습니다. 개인 업무 틀은 .json 파일로 따로 보관하고 「뼈대 가져오기」로 넣습니다.

## v82 (총괄 · js/hub.js)
- 새 메뉴 `#/hub`(총괄). 탭: 총괄판(내 업무 단계별·기한·멈춤 + 공문·사안·안건·요청 숫자) · 연간 사이클(`S.cycle{월:[{id,t,done:{학년도:true}}]}`) · 월 점검(공문·예산·서류·사안·요청 한 화면) · 안건(`S.agenda`, 결정→업무 카드) · 사안 대장(`S.cases`, 번호·단계·기한만) · 요청(`S.reqs`) · 돌아보기(`S.retro`).
- 인수인계 한 권: A.hubHand(.doc). 사안 메모는 챗봇 chunk와 인수인계 문서에 넣지 않습니다.
- 개인정보 주의: 사안 메모에 이름이 있으면(hasName) 저장 전 경고. 모든 데이터는 이 기기 localStorage.
